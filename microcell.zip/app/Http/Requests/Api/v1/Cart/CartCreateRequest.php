<?php

namespace App\Http\Requests\Api\v1\Cart;

use Illuminate\Foundation\Http\FormRequest;

class CartCreateRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array|string>
     */
    public function rules(): array
    {
        //dd($this->request);
        return [
            'product_id' => ['required', 'integer'],
            'attributoName' => ['required'],
            'attribute_id' => ['required', 'integer'],
            'quantidade' => ['required', 'integer'],
            
        ];
    }
}
