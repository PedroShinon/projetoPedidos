<x-mail::message>
# Conta MicroCell

Sua conta foi registrada com sucesso e passará por uma breve analise,
não se preocupe e apenas aguarde o segundo email que informará da liberação, agradecemos pela preferência!

<x-mail::button :url="'https://microcell-app.vercel.app/'">
Contato
</x-mail::button>

Agradecimentos,<br>
{{ config('app.name') }}
</x-mail::message>
