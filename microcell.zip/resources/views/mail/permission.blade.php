<x-mail::message>
# Conta MicroCell

Sua conta foi avaliada com sucesso e permitida o devido acesso, agradecemos pela preferência!

<x-mail::button :url="'https://microcell-app.vercel.app/'">
Visitar agora
</x-mail::button>

Agradecimentos,<br>
{{ config('app.name') }}
</x-mail::message>
